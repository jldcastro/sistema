<div class="form-group has-feedback col-md-12">
    {!!Form::label('nombre','Tipo equipo',['class' => 'col-md-2 control-label'])!!}
    {!!Form::text('nombre',null,['class' => 'form-control input'])!!}
</div>










