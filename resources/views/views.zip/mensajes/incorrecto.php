<div class="form-group has-feedback col-md-12">
    <div class="alert alert-danger">
        <?php  echo $mensaje; ?>
    </div>
</div>